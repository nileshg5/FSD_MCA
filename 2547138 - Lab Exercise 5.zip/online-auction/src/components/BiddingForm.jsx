import { useState } from "react";
import Modal from "./Modal";

export default function BiddingForm() {
  const [name, setName] = useState("");
  const [bid, setBid] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <div>
      <h2 className="text-xl mb-4">Place a Bid</h2>
      {!submitted ? (
        <form
          className="max-w-sm mx-auto bg-white p-6 rounded shadow flex flex-col gap-4"
          onSubmit={handleSubmit}
        >
          <input
            className="border px-2 py-1 rounded"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Your Name"
            required
          />
          <input
            className="border px-2 py-1 rounded"
            value={bid}
            onChange={e => setBid(e.target.value)}
            placeholder="Bid Amount"
            type="number"
            min="1"
            required
          />
          <button className="bg-blue-500 text-white rounded py-1">Submit Bid</button>
        </form>
      ) : (
        <Modal message={`Thank you, ${name}! Your bid of $${bid} has been submitted.`} />
      )}
    </div>
  );
}
