function ItemCard({ title, currentBid }) {
  return (
    <div className="p-4 shadow rounded bg-white m-2">
      <h3 className="font-semibold">{title}</h3>
      <p>Current Bid: <span className="text-green-600">{currentBid}</span></p>
    </div>
  );
}

export default function Items() {
  const items = [
    { id: 1, title: "Antique Clock", currentBid: "$120" },
    { id: 2, title: "Vintage Painting", currentBid: "$350" },
  ];
  return (
    <div>
      <h2 className="text-xl mb-4">Auction Items</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {items.map(({ id, ...item }) => (
          <ItemCard key={id} {...item} />
        ))}
      </div>
    </div>
  );
}
