export default function Modal({ message }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white p-4 rounded shadow-lg">
        <p className="mb-2">{message}</p>
      </div>
    </div>
  );
}
