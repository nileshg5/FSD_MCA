import { useState } from "react";
import item1 from "./images/item1.jpg";
import item2 from "./images/item2.jpg";
import item3 from "./images/item3.jpg";

const images = [item1, item2, item3];
export default function Carousel() {
  const [idx, setIdx] = useState(0);
  return (
    <div className="relative w-full max-w-2xl mx-auto rounded h-96 flex flex-col items-center justify-center bg-white">
      <img src={images[idx]} alt="" className="rounded shadow w-full h-48 object-cover" />
      <button onClick={() => setIdx((idx + images.length - 1) % images.length)}
        className="absolute left-0 top-1/2 -translate-y-1/2 px-2">{"<"}</button>
      <button onClick={() => setIdx((idx + 1) % images.length)}
        className="absolute right-0 top-1/2 -translate-y-1/2 px-2">{">"}</button>
    </div>
  );
}
