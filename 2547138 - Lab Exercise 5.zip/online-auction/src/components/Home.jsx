import Carousel from "./Carousel";

export default function Home() {
  return (
    <div className="text-center">
      <h1 className="text-2xl font-bold mb-4 ">Welcome to the Auction!</h1>
      <Carousel />
    </div>
  );
}
