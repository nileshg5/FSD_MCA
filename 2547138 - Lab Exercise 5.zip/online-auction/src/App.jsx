import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./components/Home";
import Items from "./components/Items";
import BiddingForm from "./components/BiddingForm";

function App() {
  return (
    <Router>
      <nav className="flex gap-4 p-4 bg-blue-300">
        <Link to="/">Home</Link>
        <Link to="/items">Items</Link>
        <Link to="/bid">Bid Now</Link>
      </nav>
      <div className="p-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/items" element={<Items />} />
          <Route path="/bid" element={<BiddingForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
